
# AnomaData Project

A brief description of what this project does and who it's for


## Appendix

Predictive Maintenance Solution utilizing machine learning for automated anomaly detection in equipment, focusing on data exploration, preprocessing, and logistic regression modeling


## Deployment

To deploy this project run

# Importing important libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

### Loading the dataset

df = pd.read_excel('AnomaData.xlsx')

# Finding the data structure

df

df.head()

df.tail()

df.info()

df.describe()

# Treating null value

df.isnull().sum()

missing_value = df.isnull().sum()
print(missing_value)

df.dropna(inplace = True)

# Convert time column to datetime datatype
df['time'] = pd.to_datetime(df['time'])


# Extracting time features
df['hour'] = df['time'].dt.hour
df['weekday'] = df['time'].dt.weekday


# feature engieneering
df['sum_x'] = df.iloc[:, 2:53].sum(axis=1) 
df['sum_x'].head()

# Mean of columns
df['mean_x'] = df.iloc[:, 2:53].mean(axis=1)  
df['mean_x'].head()


# plotting histogram
plt.hist(df['sum_x'], bins=20)  # Adjust the number of bins as needed
plt.xlabel('Sum of column')
plt.ylabel('Frequency')
plt.title('Distribution of Sum of column')
plt.show()

# ploting the [mean_x]
plt.bar(df.index, df['mean_x'])
plt.title('Mean of columns')
plt.xlabel('Index')
plt.ylabel('Mean Value')
plt.grid(axis='y')
plt.show()

# Ploting correlation_matrix
correlation_matrix = df.corr()
plt.figure(figsize=(300, 250))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', annot_kws={"size": 80})
plt.show()

# Handling outliers using IQR method
def remove_outliers(data, column):
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    return data[(data[column] >= lower_bound) & (data[column] <= upper_bound)]

# Apply remove_outliers function to each numeric column
numeric_columns = df.select_dtypes(include=['number']).columns
for col in numeric_columns:
    data = remove_outliers(df, col)

# Train/Test Split
X = df.drop(columns=['y', 'time'])
y = df['y']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# Model Selection and Training
## Random Forest
rf_classifier = RandomForestClassifier(random_state=42)
rf_classifier.fit(X_train, y_train)

## Gradient Boosting
gb_classifier = GradientBoostingClassifier(random_state=42)
gb_classifier.fit(X_train, y_train)


## Logistic Regression
logistic_classifier = LogisticRegression(random_state=42)
logistic_classifier.fit(X_train, y_train)


## SVC
svc_classifier = SVC(random_state=42)
svc_classifier.fit(X_train, y_train)


## KNN
knn_classifier = KNeighborsClassifier()
knn_classifier.fit(X_train, y_train)

## Evaluate models
def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy of the model on test data: {:.2f}%".format(accuracy * 100))
    print("Classification Report:\n", classification_report(y_test, y_pred))

# Printing the different model test result 
print("Random Forest Classifier:")
evaluate_model(rf_classifier, X_test, y_test)

print("Gradient Boosting Classifier:")
evaluate_model(gb_classifier, X_test, y_test)

print("Logistic Regression Classifier:")
evaluate_model(logistic_classifier, X_test, y_test)

print("SVC Classifier:")
evaluate_model(svc_classifier, X_test, y_test)

print("KNN Classifier:")
evaluate_model(knn_classifier, X_test, y_test)

# Compare all models
classifiers = {
    "Random Forest Classifier": rf_classifier,
    "Gradient Boosting Classifier": gb_classifier,
    "Logistic Regression Classifier": logistic_classifier,
    "SVC Classifier": svc_classifier,
    "KNN Classifier": knn_classifier
}

best_accuracy = 0
best_model = None

# finding the best model
for name, model in classifiers.items():
    print(name + ":")
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy of the model on test data: {:.2f}%".format(accuracy * 100))
    print("Classification Report:\n", classification_report(y_test, y_pred))
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_model = model

print("Best Model:")
print(best_model)

